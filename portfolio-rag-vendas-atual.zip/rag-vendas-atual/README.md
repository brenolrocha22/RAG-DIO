# RAG de vendas - versao atual

Snapshot do chatbot Chainlit + LlamaIndex deste projeto, preservado antes de iniciar o novo desafio de carros.

## Executar

1. Copie `.env.example` para `.env` e configure `OPENROUTER_API_KEY` com sua propria chave.
2. Execute `docker compose up --build`.
3. Acesse http://localhost:8000.

O CSV da pasta `data/` alimenta o indice RAG. O indice persistente fica no volume Docker.

## Seguranca e GitHub

O arquivo `.env`, chaves, ambientes virtuais, indices locais e a pasta privada `.files/` nao fazem parte deste arquivo. Nunca publique credenciais.
